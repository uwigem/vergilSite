import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.Robot; 
import java.awt.MouseInfo; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class prototypeOld extends PApplet {

//https://upload.wikimedia.org/wikipedia/commons/c/c1/Sarrus_rule_cross_product.svg



final public int CENTERX = 640;
final public int CENTERY = 480;
//gets the maximum positive screen coordinate before conversion into pixels
final public float SCREENXMAX = 1 / tan(radians(40));
final public float SCREENYMAX = 1 / tan(radians(45));

public static float playerHeight = 0.75f;

Sector sec[] = new Sector[2];


Sector currentSec;

ScreenLine[] currentWall = 
{
  new ScreenLine(0,0,0,0),
  new ScreenLine(0,0,0,0)
};

public java.awt.Robot rob;
public Line POV = new Line(-20,0.5f,20,0.5f,0);
public Point Intersect = new Point(0,0,0);
public int printSec = 0;

public void setup()
{
  size(CENTERX*2,CENTERY*2);
  strokeWeight(2);
  try
  {
    rob = new java.awt.Robot();
  }
  catch(Throwable e)
  {  }
  sec[0] = new Sector(0);
  sec[1] = new Sector(1);
//  sec[2] = new Sector(2);
  sec[1].windows[0] = sec[0].windows[0];
  sec[1].windows[1] = sec[0].windows[1];
//  sec[1].windows[2] = new Line(0,4,4,8,2-playerHeight);
//  sec[1].windows[3] = new Line(0,4,4,8,0-playerHeight);
//  sec[2].windows[0] = sec[1].windows[2];
//  sec[2].windows[1] = sec[1].windows[3];
  currentSec = sec[0];
  //noCursor();
}

public void draw()
{
  background(255);
  checkCollision();
  //TwoDee();
  ThreeDee();
  println(printSec);
  
}

public void ThreeDee()
{
  //draws the windows in the sector you're inside of
  if(currentSec.windows != null)
  {
    for(int i=0;i<currentSec.windows.length;i++)
    {
      drawWall(currentSec.windows[i]);
      //draw the window
      if(i%2 == 1)
     {
       //TODO add in the drawSector function
       drawSector(currentSec.neighbors[i]);
       //println(currentSec.neighbors[i]);
       fillWall(false);
     }
    }
  }
  //draws all of the walls in the sector you're inside of
  for(int i=0;i<currentSec.walls.length;i++)
  {
    drawWall(currentSec.walls[i]);
    
    if(i%2 == 1) fillWall(true);
  }
}

public void drawSector(int secNum)
{
  Sector drawSec = sec[secNum];
  //draws the windows in the sector you're inside of
  if(drawSec.windows != null)
  {
    for(int i=0;i<drawSec.windows.length;i++)
    {
      drawWall(drawSec.windows[i]);
      //draw the window
      if(i%2 == 1)
      {
       //TODO add in the drawSector function
       //drawSector(currentSec.neighbors[i]);
       fillWall(false);
      }
    }
  }
  //draws all of the walls in the sector you're inside of
  for(int i=0;i<drawSec.walls.length;i++)
  {
    drawWall(drawSec.walls[i]);
    
    if(i%2 == 1) fillWall(true);
  }
}

public void drawWall(Line L)
{
  boolean ceiling;
  if(L.tall != 0-playerHeight) ceiling = true;
  else            ceiling = false;
  //if the wall is completely behind the player don't draw it
  if(L.z1 < 0 && L.z2 < 0) return;
    
  //if a wall is partially behind the player
  if(L.z1 < 0 || L.z2 < 0)
  {
    if(getLineIntersection(L,POV))
    {
      //draw clipped line
      if(L.z1 < 0)
      {
        drawLine(CENTERX+(Intersect.x/Intersect.z)/SCREENXMAX*CENTERX,CENTERY-(L.tall/Intersect.z)/SCREENYMAX*CENTERY,CENTERX+(L.x2/L.z2)/SCREENXMAX*CENTERX,CENTERY-(L.tall/L.z2)/SCREENYMAX*CENTERY, ceiling);
      }
      else
      {
        drawLine(CENTERX+(L.x1/L.z1)/SCREENXMAX*CENTERX,CENTERY-(L.tall/L.z1)/SCREENYMAX*CENTERY,CENTERX+(Intersect.x/Intersect.z)/SCREENXMAX*CENTERX,CENTERY-(L.tall/Intersect.z)/SCREENYMAX*CENTERY, ceiling);
      }
      //println(intersect.x + ", " + intersect.z);
    }
  }
  else
  {
    //to get the x position it is the center plus the percentage of the way to the max times half the screen
    drawLine(CENTERX+(L.x1/L.z1)/SCREENXMAX*CENTERX,CENTERY-(L.tall/L.z1)/SCREENYMAX*CENTERY,CENTERX+(L.x2/L.z2)/SCREENXMAX*CENTERX,CENTERY-(L.tall/L.z2)/SCREENYMAX*CENTERY, ceiling);
  }
}

public void drawLine(float x1, float y1, float x2, float y2, boolean ceiling)
{
  line(x1,y1,x2,y2);
  int i;
  if(ceiling) i = 1;
  else        i = 0;
  
  //sets the current wall so that
  //the fill function knows what to fill
  currentWall[i].x1 = x1;
  currentWall[i].y1 = y1;
  currentWall[i].x2 = x2;
  currentWall[i].y2 = y2;
  return;
}

public boolean getLineIntersection(Line A, Line B)
{
    float s02_x, s02_z, s10_x, s10_z, s32_x, s32_z, s_numer, t_numer, denom, t;
    s10_x = A.x2 - A.x1;
    s10_z = A.z2 - A.z1;
    s32_x = B.x2 - B.x1;
    s32_z = B.z2 - B.z1;

    denom = s10_x * s32_z - s32_x * s10_z;
//    if (denom == 0)
//        return true; // Collinear
//DON'T CHANGE THIS because then you won't get the coordinate
    boolean denomPositive = denom > 0;

    s02_x = A.x1 - B.x1;
    s02_z = A.z1 - B.z1;
    s_numer = s10_x * s02_z - s10_z * s02_x;
    if ((s_numer < 0) == denomPositive)
        return false; // No collision

    t_numer = s32_x * s02_z - s32_z * s02_x;
    if ((t_numer < 0) == denomPositive)
        return false; // No collision

    if (((s_numer > denom) == denomPositive) || ((t_numer > denom) == denomPositive))
        return false; // No collision
    // Collision detected
    t = t_numer / denom;
    if (Intersect != null)
    {
        Intersect.x = A.x1 + (t * s10_x);
        Intersect.z = A.z1 + (t * s10_z);
    }

    return true;
}

public boolean getIntersection(Line A, Line B)
{
  //uses vector cross product BLACK MAGIC to find the intersection
  float s1_x, s1_z, s2_x, s2_z;
  s1_x = A.x2 - A.x1;     s1_z = A.z2 - A.z1;
  s2_x = B.x2 - B.x1;     s2_z = B.z2 - B.z1;
  
  float s, t;
  s = (-s1_z * (A.x1 - B.x1) + s1_x * (A.z1 - B.z1)) / (-s2_x * s1_z + s1_x * s2_z);
  t = ( s2_x * (A.z1 - B.z1) - s2_z * (A.x1 - B.x1)) / (-s2_x * s1_z + s1_x * s2_z);
  
  if(s >= 0 && s <= 1 && t >= 0 && t <= 1)
  {
    Intersect.x = A.x1+(t*s1_x);
    Intersect.z = A.z1+(t*s1_z);
    return true;
  }
  return false;
}

public float pDistance(Line L) {

  float A = 0 - L.x1;
  float B = 0 - L.z1;
  float C = L.x2 - L.x1;
  float D = L.z2 - L.z1;

  float dot = A * C + B * D;
  float len_sq = C * C + D * D;
  float param = -1;
  if (len_sq != 0) //in case of 0 length line
      param = dot / len_sq;

  float xx, zz;

  if (param < 0) {
    xx = L.x1;
    zz = L.z1;
  }
  else if (param > 1) {
    xx = L.x2;
    zz = L.z2;
  }
  else {
    xx = L.x1 + param * C;
    zz = L.z1 + param * D;
  }

  float dx = 0 - xx;
  float dz = 0 - zz;
  return (float)Math.sqrt(dx * dx + dz * dz);
}

//public bool isLeft(Point a, Point b, Point c){
//     return ((b.x - a.x)*(c.y - a.y) - (b.y - a.y)*(c.x - a.x)) > 0;
//}
public boolean isRight(Line L){
  return ((L.x2 - L.x1)*(0 - L.z1) - (L.z2 - L.z1)*(0 - L.x1)) > 0;
}


public boolean inPolygon(Sector s) {

  int   polyCorners = s.polyCorners;
  int   i, j = polyCorners - 1;
  boolean  oddNodes=false;

  for (i=0; i<polyCorners; i++) {
    if (s.poly[i].z<0 && s.poly[j].z>=0 ||  s.poly[j].z<0 && s.poly[i].z>=0) 
    {
      if (s.poly[i].x+(0-s.poly[i].z)/(s.poly[j].z-s.poly[i].z)*(s.poly[j].x-s.poly[i].x)<0) 
      {
        oddNodes=!oddNodes; 
      }
    }
    j=i;
  }

  return oddNodes; 
}

public void checkCollision()
{
  /*
  for(int i=0;i<currentSec.windows.length;i+=2)
  {
    Line cWindow = currentSec.windows[i];
    
    println("Now Right: " + isRight(currentSec.windows[i]));
    println("Was Right: " + currentSec.windows[i].pIsRight);
    
    println(inPolygon(sec[0]));
    //if(getIntersection(cWindow, Collider[0]) || getIntersection(cWindow, Collider[1]) || getIntersection(cWindow, Collider[2]) || getIntersection(cWindow, Collider[3]))
    //if(pDistance(cWindow) < 1)
    
    if(getIntersection(cWindow, Collider))
    {
      println("FJIDSJFLJESFJSLJFESJLFJL ");
      if(cWindow.pIsRight != isRight(cWindow))
      {
        int switchTo;
        //if the player is right
        if(!cWindow.pIsRight == true) switchTo = cWindow.Rneighbor;
        else                          switchTo = cWindow.Lneighbor;
        println("SWITCH TO " + switchTo);
        
        //**WARNING! THIS CODE IS UNSTABLE
        //**This will only work if the window being crossed is at the same index on both sectors
        
        currentSec.windows[i].pIsRight = !currentSec.windows[i].pIsRight;
        printSec = switchTo;
        currentSec = sec[switchTo];
      }
    }
  }
  */
  println("sec 0: " + inPolygon(sec[0]));
  println("sec 1: " + inPolygon(sec[1]));
  if(!inPolygon(currentSec))
  {
    println("YEEEEEEER IIIIIIIIIIIIIIN THEEEEEEEEEE WROOOOOOONG SEEEEEEEECTOOOOOOOOOOOOR");
    for(int i=0; i<currentSec.neighbors.length;i+=2)
    {
      if(inPolygon(sec[currentSec.neighbors[i]]))
      {
        printSec = currentSec.neighbors[i];
        currentSec = sec[printSec];
      }
    }
  }
}

public void keyTyped()
{
  float moveX = 0;
  float moveZ = 0;
  float moveAngle = 0;
  
  if(key =='w')
  {
    moveZ = -0.125f;
  }
  if(key == 's')
  {
    moveZ = 0.125f;
  }
  if(key == 'a')
  {
    moveX = 0.125f;
  }
  if(key == 'd')
  {
    moveX = -0.125f;
  }
  if(key == 'j')
  {
    moveAngle = -PI/45;
  }
  if(key == 'l')
  {
    moveAngle = PI/45;
  }
  if(key == 'y')
  {
    if(currentSec == sec[0])
    {
      currentSec = sec[1];
    }
    else
    {
      currentSec = sec[0];
    }
  }
  if(key == '1') 
  {
    currentSec = sec[0];
    printSec = 0;
  }
  if(key == '2') 
  {
    currentSec = sec[1];
    printSec = 1;
  }
  update(moveX, moveZ, moveAngle);
}

public void update(float moveX, float moveZ, float moveAngle)
{
  for(int j=0;j<sec.length;j++)
  {
    Sector cSec = sec[j];
    for(int i=0;i<cSec.walls.length;i++)
    {
      float tempX = cSec.walls[i].x1;
      float tempZ = cSec.walls[i].z1;
      
      cSec.walls[i].x1 += moveX;
      cSec.walls[i].z1 += moveZ;
      cSec.walls[i].x2 += moveX;
      cSec.walls[i].z2 += moveZ;
      if(moveAngle != 0)
      {
        cSec.walls[i].x1 = tempX*cos(moveAngle) - tempZ*sin(moveAngle);
        cSec.walls[i].z1 = tempX*sin(moveAngle) + tempZ*cos(moveAngle);
        
        tempX = cSec.walls[i].x2;
        tempZ = cSec.walls[i].z2;
        cSec.walls[i].x2 = tempX*cos(moveAngle) - tempZ*sin(moveAngle);
        cSec.walls[i].z2 = tempX*sin(moveAngle) + tempZ*cos(moveAngle);
      }
    }
    for(int i=0;i<cSec.windows.length;i++)
    {
      float tempX = cSec.windows[i].x1;
      float tempZ = cSec.windows[i].z1;
      
      cSec.windows[i].x1 += moveX;
      cSec.windows[i].z1 += moveZ;
      cSec.windows[i].x2 += moveX;
      cSec.windows[i].z2 += moveZ;
      if(moveAngle != 0)
      {
        cSec.windows[i].x1 = tempX*cos(moveAngle) - tempZ*sin(moveAngle);
        cSec.windows[i].z1 = tempX*sin(moveAngle) + tempZ*cos(moveAngle);
        
        tempX = cSec.windows[i].x2;
        tempZ = cSec.windows[i].z2;
        cSec.windows[i].x2 = tempX*cos(moveAngle) - tempZ*sin(moveAngle);
        cSec.windows[i].z2 = tempX*sin(moveAngle) + tempZ*cos(moveAngle);
      }
    }
    for(int i=0;i<cSec.poly.length;i++)
    {
      Point cSp = cSec.poly[i];
      float tempX = cSp.x;
      float tempZ = cSp.z;
      
      cSp.x += moveX;
      cSp.z += moveZ;
      if(moveAngle != 0)
      {
        cSec.poly[i].x = tempX*cos(moveAngle) - tempZ*sin(moveAngle);
        cSec.poly[i].z = tempX*sin(moveAngle) + tempZ*cos(moveAngle);
      }
    }
  }
}

public void fillWall(boolean wall)
{
  fill(200,100,50);
  //Ceilings
  beginShape();
  stroke(200,100,50);
  vertex(currentWall[1].x1,0);
  vertex(currentWall[1].x2,0);
  vertex(currentWall[1].x2,currentWall[1].y2);
  vertex(currentWall[1].x1,currentWall[1].y1);
  endShape();
  stroke(2);
  
  //println("FHEKFSEJFLJSEJ");
  
  fill(50,100,200);
  //Floor
  beginShape();
  stroke(50,100,200);
  vertex(currentWall[0].x1,currentWall[0].y1);
  vertex(currentWall[0].x2,currentWall[0].y2);
  vertex(currentWall[0].x2,CENTERY*2);
  vertex(currentWall[0].x1,CENTERY*2);
  endShape();
  stroke(2);
  
  if(wall)
  {
    fill(128);
    //Start the wall
    beginShape();
    vertex(currentWall[0].x1,currentWall[0].y1);
    vertex(currentWall[1].x1,currentWall[1].y1);
    vertex(currentWall[1].x2,currentWall[1].y2);
    vertex(currentWall[0].x2,currentWall[0].y2);
    endShape();
  }
}



public void TwoDee()
{
//  for(int i=0;i<lines.length;i++)
//  {
//    line(CENTERX+lines[i].x1*10,CENTERY-lines[i].z1*10,CENTERX+lines[i].x2*10,CENTERY-lines[i].z2*10);
//  }
//  ellipse(CENTERX,CENTERY,10,10);
}

public void mouseMoved()
{
  //float x = java.awt.MouseInfo.getPointerInfo().getLocation().x;
  //update(0,0,(x));
}
public class Line
{
  float x1;
  float z1;
  float x2;
  float z2;
  float tall;
  int Lneighbor;
  int Rneighbor;
  boolean pIsRight;
  
  Line(float x1, float z1, float x2, float z2, float tall)
  {
    this.x1 = x1;
    this.z1 = z1;
    this.x2 = x2;
    this.z2 = z2;
    this.tall = tall;
  }
  
  Line(float x1, float z1, float x2, float z2, float tall, int nl, int nr, boolean r)
  {
    this.x1 = x1;
    this.z1 = z1;
    this.x2 = x2;
    this.z2 = z2;
    this.tall = tall;
    Lneighbor = nl;
    Rneighbor = nr;
    pIsRight = r;
  }
}
public class Point
{
  float x;
  float y;
  float z;
  Point(float x, float y, float z)
  {
    this.x = x;
    this.y = y;
    this.z = z;
  }
}
public class ScreenLine
{
  float x1;
  float y1;
  float x2;
  float y2;
  
  ScreenLine(float x1, float z1, float x2, float z2)
  {
    this.x1 = x1;
    this.y1 = z1;
    this.x2 = x2;
    this.y2 = z2;
  }
}
public class Sector
{
  Line[] walls;
  Line[] windows;
  int[] neighbors;
  Point[] poly;
  int polyCorners;
  Sector(int i)
  {
    switch(i)
    {
      case 0:
        walls = new Line[] {
          new Line(0,4,-4,8,2-playerHeight),
          new Line(0,4,-4,8,0-playerHeight),
          new Line(-4,8,-8,4,2-playerHeight),
          new Line(-4,8,-8,4,0-playerHeight),
          new Line(-8,4,-8,-4,2-playerHeight),
          new Line(-8,4,-8,-4,0-playerHeight),
          new Line(-8,-4,0,-4,2-playerHeight),
          new Line(-8,-4,0,-4,0-playerHeight)
//          ,
//          new Line(0,4,0,0,2-playerHeight),
//          new Line(0,4,0,0,0-playerHeight)
        };
        windows = new Line[] {
          new Line(0,-4,0,4,2-playerHeight, 0, 1, false),
          new Line(0,-4,0,4,0-playerHeight, 0, 1, false)
        };
        poly = new Point[] {
          new Point(0,0,4),
          new Point(-4,0,8),
          new Point(-8,0,4),
          new Point(-8,0,-4),
          new Point(0,0,-4)
        };
        polyCorners = 5;
        neighbors = new int[] { 1,1 };
        break;
      case 1:
        walls = new Line[] {
          new Line(0,4,4,8,2-playerHeight),
          new Line(0,4,4,8,0-playerHeight),
          new Line(4,8,8,4,2-playerHeight),
          new Line(4,8,8,4,0-playerHeight),
          new Line(8,4,8,-4,2-playerHeight),
          new Line(8,4,8,-4,0-playerHeight),
          new Line(8,-4,0,-4,2-playerHeight),
          new Line(8,-4,0,-4,0-playerHeight)
        };
        windows = new Line[2];
//        {
//          new Line(1,4,1,-4,2-playerHeight, 0, false),
//          new Line(1,4,1,-4,0-playerHeight, 0, false),
//        };
        poly = new Point[] {
          new Point(0,0,4),
          new Point(4,0,8),
          new Point(8,0,4),
          new Point(8,0,-4),
          new Point(0,0,-4),
        };
        polyCorners = 5;
        neighbors = new int[] {0,0};
        break;
      case 2:
        walls = new Line[] {
//          new Line(0,4,4,8,2-playerHeight),
//          new Line(0,4,4,8,0-playerHeight),
          new Line(4,8,4,12,2-playerHeight),
          new Line(4,8,4,12,0-playerHeight),
          new Line(4,12,-4,12,2-playerHeight),
          new Line(4,12,-4,12,0-playerHeight),
          new Line(-4,12,-4,4,2-playerHeight),
          new Line(-4,12,-4,4,0-playerHeight),
          new Line(-4,4,0,4,2-playerHeight),
          new Line(-4,4,0,4,0-playerHeight)
        };
        windows = new Line[2];
        poly = new Point[] {
          new Point(4,0,8),
          new Point(4,0,12),
          new Point(-4,0,12),
          new Point(-4,0,4),
          new Point(0,0,4)
        };
        polyCorners = 5;
        neighbors = new int[] {1,1};
        break;
        /*
      case 2:
        walls = new Line[] {
          new Line(8,4,12,4,2-playerHeight),
          new Line(8,4,12,4,0-playerHeight),
          new Line(12,4,8,-4,2-playerHeight),
          new Line(12,4,8,-4,0-playerHeight),
          new Line(8,-4,4,0,2-playerHeight),
          new Line(8,-4,4,0,0-playerHeight)
        };
        windows = new Line[] {
          new Line(4,0,8,4,2-playerHeight),
          new Line(4,0,8,4,0-playerHeight)
        };
        neighbors = new int[] {0,0,1,1};
        wasRight = new boolean[neighbors.length];
        break;
        */
    }
    
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "prototypeOld" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
